from django.urls import path
from . import views

urlpatterns = [
    path('', views.register, name='home'),
    path('register/', views.register, name='register'),
    path('login/', views.user_login, name='login'),
    path('welcome/', views.welcome, name='welcome'),
    path('home/', views.home_view, name='home_view'),
    path('logout/', views.user_logout, name='logout'),
]