from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from .models import CustomUser

def register(request):
    if request.method == "POST":
        full_name = request.POST.get("fullname")
        email = request.POST.get("email")
        username = request.POST.get("username")
        password = request.POST.get("password")
        confirm_password = request.POST.get("confirm_password")

        if not full_name or not email or not username or not password:
            messages.error(request, "All fields are required!")
            return redirect("register")

        if password != confirm_password:
            messages.error(request, "Passwords do not match!")
            return redirect("register")

        if CustomUser.objects.filter(email=email).exists():
            messages.error(request, "Email already registered!")
            return redirect("register")

        if CustomUser.objects.filter(username=username).exists():
            messages.error(request, "Username already taken!")
            return redirect("register")

        user = CustomUser.objects.create_user(username=username, email=email, password=password, full_name=full_name)
        messages.success(request, "Registration successful! You can now log in.")
        return redirect("login")

    return render(request, "register.html")

def user_login(request):
    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")

        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            messages.success(request, "Login successful!")
            return redirect("welcome")
        else:
            messages.error(request, "Invalid username or password")
            return redirect("login")

    return render(request, "login.html")

def welcome(request):
    if request.method == "POST":
        if "entertainment" in request.POST:
            # Redirect to home with Pomodoro timer flag
            return redirect("home_view")
        elif "flourish" in request.POST:
            # Redirect to home without Pomodoro timer
            return redirect("home_view")
    return render(request, "welcome.html")

def home_view(request):
    # Check if pomodoro flag is in the URL query parameters
    start_pomodoro = request.GET.get("pomodoro", "false") == "true"
    return render(request, "home.html", {"start_pomodoro": start_pomodoro})

def user_logout(request):
    logout(request)
    return redirect("login")