document.getElementById("login-form").addEventListener("submit", function (event) {
    const username = document.querySelector('input[name="username"]').value;
    const password = document.querySelector('input[name="password"]').value;

    if (username === "" || password === "") {
        alert("Please enter your username and password!");
        event.preventDefault(); // Prevent form submission
    } else {
        alert("Login successful!");
    }
});
